from django.shortcuts import render,HttpResponseRedirect
from django.views import View
from django.contrib.auth.models import User ,Group
from django.contrib.auth import authenticate,login,logout,update_session_auth_hash

from .forms import UserCreateforms,LoginForm,EditUserProfileForm
from django.contrib import messages
from django.core.paginator import Paginator
from django.http import JsonResponse
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
# Create your views here.
class Home(View):
    tamplate_name = "home.html"
    def get(self,request):
        return render(request,self.tamplate_name)
    def post(self,request):
        return render(request,self.tamplate_name)

class CreateAccount(View):
    tamplate_name = "sign_up.html"
    def get(self,request):
        fm=UserCreateforms()
        return render(request,self.tamplate_name,{"form":fm})
    def post(self,request):
        if request.method=='POST':
            fm=UserCreateforms(request.POST)
            if fm.is_valid():
                messages.success(request, "Congratulations Your account created")
                user=fm.save()
                # group created
                group = Group.objects.get_or_create(name="Author")
                group = Group.objects.get(name='Author')
                user.groups.add(group)
                fm =UserCreateforms()
        else:
            fm=UserCreateforms()
        return render(request,self.tamplate_name,{'form':fm})

class UserLogin(View):
    template_name="login.html"
    def get(self,request):
        fm=LoginForm()
        return render(request, self.template_name,{'form':fm})

    def post(self,request):
        if request.method=='POST':
            fm = LoginForm(request=request,data=request.POST)
            if fm.is_valid():
                uname = fm.cleaned_data['username']
                upass = fm.cleaned_data['password']
                user = authenticate(username=uname,password=upass)
                if user is not None:
                    login(request,user)
                    group = Group.objects.get(name='Author')
                    users = group.user_set.all()
                    return HttpResponseRedirect('/')
        else:
            fm=LoginForm()
        return render(request, self.template_name,{'form':fm})
class UserProfile_Data(View):
    template_name="userprofiledata.html"
    def get(self,request,id):
        if request.user.is_authenticated:
            userdata=get_user_model().objects.filter(id=id)
            for i in userdata:
                fm = EditUserProfileForm(instance=i)
                print(id)
                return render(request,self.template_name,{'form':fm})
        else:
            return HttpResponseRedirect('/del/login')

    def post(self,request,id):
        if request.user.is_authenticated:
            userdata=get_user_model().objects.filter(id=id)
            for i in userdata:
                fm=EditUserProfileForm(request.POST,instance=i)
                if fm.is_valid():
                    fm.save()
                    fm = EditUserProfileForm(instance=i)
                    return HttpResponseRedirect('/del/userall')
                    # return render(request,self.template_name,{'form':fm})
        else:
            return HttpResponseRedirect('/del/login')

class Delete_Account(View):
    def get(self,request,id):
        if request.user.is_authenticated:
            data1=get_user_model().objects.filter(id=id)
            data1.delete()
            return HttpResponseRedirect('/del/userall')
        else:
            return HttpResponseRedirect('/del/login')

class AllUserData(View):
    template_name="userdata.html"
    def get(self,request):
        print(request.user)
        if request.user.is_authenticated:
            all_users= get_user_model().objects.all()
            usersList = User.objects.values_list()
            paginator = Paginator(all_users, 5)  # Show 10 contacts per page.
            page_number = request.GET.get('page')
            page_obj = paginator.get_page(page_number)
            # userdata=get_user_model().objects.filter(username='tech1xfgg')
            return render(request,self.template_name,{'page_obj':page_obj})
        else:
            return HttpResponseRedirect('/del/login')
  

# Logout_User
class User_logout(View):
    def get(self,request):
        if request.user.is_authenticated:
            logout(request)
            return HttpResponseRedirect('/del/login')
        else:
            return HttpResponseRedirect('/del/login')
